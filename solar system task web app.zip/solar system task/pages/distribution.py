import pandas as pd
import dash
from dash import dcc, html, callback
import plotly.express as px
from dash.dependencies import Input, Output

dash.register_page(__name__, path='/distribution', name="Distribution 📊")

####################### LOAD DATASET #############################
Solar_df = pd.read_csv("Data.csv")

####################### HISTOGRAM ###############################
def create_distribution(col_name="perihelion"):
    return px.histogram(data_frame=Solar_df, x=col_name, height=600)

####################### WIDGETS ################################
columns = ["Name", "perihelion", "aphelion", "eccentricity", "density", "gravity", "escape", "average_total_radius", "average_equatorial_radius", "average_polar_radius", "flattening",	"dimension", "sideralOrbit", "sideralRotation",	"discoveryDate", "mass_kg",	"volume", "orbit_type", "orbits", "bondAlbido",	"geomAlbido", "RV_abs", "p_transit", "transit_visibility", "transit_depth",	"mass_compared_to_jupyter",	"semimajorAxis_A",	"grav_int"]
dd = dcc.Dropdown(id="dist_column", options=columns, value="perihelion", clearable=False)

####################### PAGE LAYOUT #############################
layout = html.Div(children=[
    html.Br(),
    html.P("Select Column:"),
    dd,
    dcc.Graph(id="histogram")
])

####################### CALLBACKS ################################
@callback(Output("histogram", "figure"), [Input("dist_column", "value")])
def update_histogram(dist_column):
    return create_distribution(dist_column)
