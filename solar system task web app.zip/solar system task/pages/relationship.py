import pandas as pd
import dash
from dash import dcc, html, callback
import plotly.express as px
from dash.dependencies import Input, Output

dash.register_page(__name__, path='/relationship', name="Relationship 📈")

####################### DATASET #############################
solar_df = pd.read_csv("Data.csv")

####################### SCATTER CHART #############################
def create_scatter_chart(x_axis="Name", y_axis="sideralOrbit"):
    return px.scatter(data_frame=solar_df, x=x_axis, y=y_axis, height=600)

####################### WIDGETS #############################
columns = ["Name", "perihelion", "aphelion", "eccentricity", "density", "gravity", "escape", "average_total_radius", "average_equatorial_radius", "average_polar_radius", "flattening",	"dimension", "sideralOrbit", "sideralRotation",	"discoveryDate", "mass_kg",	"volume", "orbit_type", "orbits", "bondAlbido",	"geomAlbido", "RV_abs", "p_transit", "transit_visibility", "transit_depth",	"mass_compared_to_jupyter",	"semimajorAxis_A",	"grav_int"]

x_axis = dcc.Dropdown(id="x_axis", options=columns, value="Name", clearable=False)
y_axis = dcc.Dropdown(id="y_axis", options=columns, value="sideralOrbit", clearable=False)

####################### PAGE LAYOUT #############################
layout = html.Div(children=[
    html.Br(),
    "X-Axis", x_axis, 
    "Y-Axis", y_axis,
    dcc.Graph(id="scatter")
])

####################### CALLBACKS ###############################
@callback(Output("scatter", "figure"), [Input("x_axis", "value"),Input("y_axis", "value"), ])
def update_scatter_chart(x_axis, y_axis):
    return create_scatter_chart(x_axis, y_axis)